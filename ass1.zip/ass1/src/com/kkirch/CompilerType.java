/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kkirch;

/**
 *
 * @author kkirch
 */
public enum CompilerType {
    MM,
    ACCUM,
    STACK,
    LDST
}
